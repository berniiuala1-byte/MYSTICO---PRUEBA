"use client"

import useSWR from "swr"
import { createClient } from "@/lib/supabase/client"
import type { Product, ProductCategory, RRPP, Shift, CashSession, Bar, Sale } from "@/lib/types"

// Create a single supabase instance for the hook
const getSupabase = () => createClient()

// Fetcher for products
async function fetchProducts(): Promise<Product[]> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("is_sellable", true)
    .eq("is_active", true)
    .order("name")
  
  if (error) throw error
  return data || []
}

// Fetcher for categories
async function fetchCategories(): Promise<ProductCategory[]> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("product_categories")
    .select("*")
    .eq("is_active", true)
    .order("sort_order")
  
  if (error) throw error
  return data || []
}

// Fetcher for RRPPs
async function fetchRRPPs(): Promise<RRPP[]> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("rrpps")
    .select("*")
    .eq("is_active", true)
    .order("full_name")
  
  if (error) throw error
  return data || []
}

// Fetcher for open shift
async function fetchOpenShift(): Promise<Shift | null> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("shifts")
    .select("*")
    .eq("status", "open")
    .single()
  
  if (error && error.code !== "PGRST116") throw error // PGRST116 = no rows found
  return data
}

// Fetcher for open cash session (requires bar_id)
async function fetchOpenCashSession(barId: string): Promise<CashSession | null> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("cash_sessions")
    .select("*")
    .eq("bar_id", barId)
    .eq("status", "open")
    .single()
  
  if (error && error.code !== "PGRST116") throw error
  return data
}

// Fetcher for bars
async function fetchBars(): Promise<Bar[]> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("bars")
    .select("*")
    .eq("is_active", true)
    .order("name")
  
  if (error) throw error
  return data || []
}

// Fetcher for recent sales
async function fetchRecentSales(cashSessionId: string): Promise<Sale[]> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("sales")
    .select("*")
    .eq("cash_session_id", cashSessionId)
    .eq("status", "completed")
    .order("created_at", { ascending: false })
    .limit(20)
  
  if (error) throw error
  return data || []
}

// Hook for products
export function useProducts() {
  return useSWR<Product[]>("products", fetchProducts, {
    revalidateOnFocus: false,
  })
}

// Hook for categories
export function useCategories() {
  return useSWR<ProductCategory[]>("categories", fetchCategories, {
    revalidateOnFocus: false,
  })
}

// Hook for RRPPs
export function useRRPPs() {
  return useSWR<RRPP[]>("rrpps", fetchRRPPs, {
    revalidateOnFocus: false,
  })
}

// Hook for open shift
export function useOpenShift() {
  return useSWR<Shift | null>("openShift", fetchOpenShift, {
    refreshInterval: 30000, // Refresh every 30 seconds
  })
}

// Hook for bars
export function useBars() {
  return useSWR<Bar[]>("bars", fetchBars, {
    revalidateOnFocus: false,
  })
}

// Hook for open cash session
export function useOpenCashSession(barId: string | null) {
  return useSWR<CashSession | null>(
    barId ? ["openCashSession", barId] : null,
    () => (barId ? fetchOpenCashSession(barId) : null),
    {
      refreshInterval: 30000,
    }
  )
}

// Hook for recent sales
export function useRecentSales(cashSessionId: string | null) {
  return useSWR<Sale[]>(
    cashSessionId ? ["recentSales", cashSessionId] : null,
    () => (cashSessionId ? fetchRecentSales(cashSessionId) : []),
    {
      refreshInterval: 10000,
    }
  )
}

// Realtime subscription hook
export function useRealtimeSubscription(
  table: string,
  onUpdate: () => void
) {
  const supabase = getSupabase()

  // Subscribe on mount
  const channel = supabase
    .channel(`pos-${table}`)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table },
      () => {
        onUpdate()
      }
    )
    .subscribe()

  return () => {
    supabase.removeChannel(channel)
  }
}
