"use client"

import { useState, useMemo, useCallback, useEffect } from "react"
import { useProducts, useCategories, useRRPPs, useOpenShift, useBars, useOpenCashSession, useRecentSales } from "@/hooks/use-pos-data"
import { createNormalSale, createGiftSale } from "@/lib/sales-actions"
import { formatCurrency } from "@/lib/types"
import type { Product, CartItem, Bar, RRPP } from "@/lib/types"
import { SessionHeader } from "@/components/pos/session-header"
import { CategoryNav } from "@/components/pos/category-nav"
import { ProductGrid } from "@/components/pos/product-grid"
import { CartPanel } from "@/components/pos/cart-panel"
import { PaymentModal } from "@/components/pos/payment-modal"
import { GiftModal } from "@/components/pos/gift-modal"
import { ReceiptModal } from "@/components/pos/receipt-modal"
import { RecentSalesModal } from "@/components/pos/recent-sales-modal"
import { SessionClosedOverlay } from "@/components/pos/session-closed-overlay"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase/client"

export default function POSPage() {
  const { toast } = useToast()
  
  // Data fetching
  const { data: products = [], isLoading: productsLoading } = useProducts()
  const { data: categories = [], isLoading: categoriesLoading } = useCategories()
  const { data: rrpps = [], isLoading: rrppsLoading } = useRRPPs()
  const { data: shift, isLoading: shiftLoading, mutate: mutateShift } = useOpenShift()
  const { data: bars = [], isLoading: barsLoading } = useBars()

  // Selected bar state (persisted in localStorage)
  const [selectedBar, setSelectedBar] = useState<Bar | null>(null)

  // Load bar from localStorage on mount
  useEffect(() => {
    if (bars.length > 0 && !selectedBar) {
      const savedBarId = localStorage.getItem("pos_selected_bar")
      const savedBar = bars.find(b => b.id === savedBarId)
      setSelectedBar(savedBar || bars[0])
    }
  }, [bars, selectedBar])

  // Cash session for selected bar
  const { data: cashSession, isLoading: cashSessionLoading, mutate: mutateCashSession } = useOpenCashSession(selectedBar?.id || null)
  
  // Recent sales for the cash session
  const { data: recentSales = [], mutate: mutateRecentSales } = useRecentSales(cashSession?.id || null)

  // Category filter
  const [selectedCategory, setSelectedCategory] = useState("all")

  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([])

  // Modal states
  const [paymentModalOpen, setPaymentModalOpen] = useState(false)
  const [giftModalOpen, setGiftModalOpen] = useState(false)
  const [receiptModalOpen, setReceiptModalOpen] = useState(false)
  const [recentSalesModalOpen, setRecentSalesModalOpen] = useState(false)
  const [lastSaleId, setLastSaleId] = useState<string | null>(null)
  
  // Loading states
  const [paymentLoading, setPaymentLoading] = useState(false)
  const [giftLoading, setGiftLoading] = useState(false)

  // Handle bar selection
  const handleSelectBar = useCallback((bar: Bar) => {
    setSelectedBar(bar)
    localStorage.setItem("pos_selected_bar", bar.id)
    setCartItems([]) // Clear cart when switching bars
  }, [])

  // Filtered products
  const filteredProducts = useMemo(() => {
    if (selectedCategory === "all") return products
    return products.filter((p) => p.category_id === selectedCategory)
  }, [selectedCategory, products])

  // Cart total
  const cartTotal = useMemo(() => {
    return cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  }, [cartItems])

  // Add product to cart
  const handleAddProduct = useCallback((product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === product.id)
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        )
      }
      return [...prev, { 
        id: product.id, 
        name: product.name, 
        price: product.sale_price || 0, 
        quantity: 1,
        image_url: product.image_url
      }]
    })
  }, [])

  // Update item quantity
  const handleUpdateQuantity = useCallback((productId: string, delta: number) => {
    setCartItems((prev) => {
      return prev
        .map((item) => {
          if (item.id === productId) {
            const newQuantity = item.quantity + delta
            return newQuantity > 0 ? { ...item, quantity: newQuantity } : null
          }
          return item
        })
        .filter(Boolean) as CartItem[]
    })
  }, [])

  // Remove item from cart
  const handleRemoveItem = useCallback((productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== productId))
  }, [])

  // Handle payment confirmation
  const handlePaymentConfirm = useCallback(
    async (result: { cashAmount: number; bankAmount: number; bankMethod: 'transfer' | 'posnet' | 'qr' | 'mercado_pago' }) => {
      if (!shift || !cashSession || !selectedBar) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "No hay sesion de caja activa",
        })
        return
      }

      setPaymentLoading(true)

      // Build payments array
      const payments: Array<{
        payment_account: 'cash' | 'bank'
        payment_method: 'cash' | 'transfer' | 'posnet' | 'qr' | 'mercado_pago'
        amount: number
      }> = []

      if (result.cashAmount > 0) {
        payments.push({
          payment_account: 'cash',
          payment_method: 'cash',
          amount: result.cashAmount,
        })
      }

      if (result.bankAmount > 0) {
        payments.push({
          payment_account: 'bank',
          payment_method: result.bankMethod,
          amount: result.bankAmount,
        })
      }

      const saleResult = await createNormalSale(
        shift.id,
        cashSession.id,
        selectedBar.id,
        cartItems,
        payments
      )

      setPaymentLoading(false)

      if (saleResult.success) {
        setPaymentModalOpen(false)
        setCartItems([])
        setLastSaleId(saleResult.saleId || null)
        setReceiptModalOpen(true)
        
        // Refresh data
        mutateRecentSales()
        mutateCashSession()

        toast({
          title: "Venta Registrada",
          description: `Total: ${formatCurrency(cartTotal)}`,
        })
      } else {
        toast({
          variant: "destructive",
          title: "Error al registrar venta",
          description: saleResult.error || "Error desconocido",
        })
      }
    },
    [shift, cashSession, selectedBar, cartItems, cartTotal, toast, mutateRecentSales, mutateCashSession]
  )

  // Handle gift confirmation
  const handleGiftConfirm = useCallback(
    async (rrpp: RRPP) => {
      if (!shift || !cashSession || !selectedBar) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "No hay sesion de caja activa",
        })
        return
      }

      setGiftLoading(true)

      const saleResult = await createGiftSale(
        shift.id,
        cashSession.id,
        selectedBar.id,
        cartItems,
        rrpp.id
      )

      setGiftLoading(false)

      if (saleResult.success) {
        setGiftModalOpen(false)
        setCartItems([])
        setLastSaleId(saleResult.saleId || null)
        setReceiptModalOpen(true)
        
        // Refresh data
        mutateRecentSales()
        mutateCashSession()

        toast({
          title: "Regalo Registrado",
          description: `${formatCurrency(cartTotal)} asignado a ${rrpp.full_name}`,
        })
      } else {
        toast({
          variant: "destructive",
          title: "Error al registrar regalo",
          description: saleResult.error || "Error desconocido",
        })
      }
    },
    [shift, cashSession, selectedBar, cartItems, cartTotal, toast, mutateRecentSales, mutateCashSession]
  )

  // Handle reprint
  const handlePrintSale = useCallback((saleId: string) => {
    setLastSaleId(saleId)
    setRecentSalesModalOpen(false)
    setReceiptModalOpen(true)
  }, [])

  // Realtime subscriptions
  useEffect(() => {
    const supabase = createClient()

    const channel = supabase
      .channel("pos-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "cash_sessions" }, () => {
        mutateCashSession()
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "shifts" }, () => {
        mutateShift()
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "sales" }, () => {
        mutateRecentSales()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [mutateCashSession, mutateShift, mutateRecentSales])

  // Loading state
  const isLoading = productsLoading || categoriesLoading || barsLoading || shiftLoading || cashSessionLoading

  // POS disabled if no open cash session
  const isPOSDisabled = !cashSession || cashSession.status !== "open"

  return (
    <div className="min-h-screen bg-background">
      <div className="relative h-screen flex flex-col">
        {/* Main Content */}
        <div className="flex-1 flex flex-col lg:flex-row gap-4 p-4 overflow-hidden">
          {/* Left Panel - Products */}
          <div className="flex-1 flex flex-col min-w-0">
            <SessionHeader 
              bar={selectedBar}
              bars={bars}
              cashSession={cashSession ?? null}
              shift={shift ?? null}
              onSelectBar={handleSelectBar}
              loading={isLoading}
            />
            
            <div className="mb-4">
              <CategoryNav
                categories={categories}
                selectedCategory={selectedCategory}
                onSelectCategory={setSelectedCategory}
              />
            </div>
            
            <div className="flex-1 overflow-y-auto pr-2">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="w-8 h-8 border-2 border-foreground/20 border-t-foreground rounded-full animate-spin" />
                </div>
              ) : (
                <ProductGrid
                  products={filteredProducts}
                  onAddProduct={handleAddProduct}
                  disabled={isPOSDisabled}
                />
              )}
            </div>
          </div>

          {/* Right Panel - Cart */}
          <div className="w-full lg:w-96 flex-shrink-0">
            <CartPanel
              items={cartItems}
              onUpdateQuantity={handleUpdateQuantity}
              onRemoveItem={handleRemoveItem}
              onCheckout={() => setPaymentModalOpen(true)}
              onGift={() => setGiftModalOpen(true)}
              onViewRecent={() => setRecentSalesModalOpen(true)}
              disabled={isPOSDisabled}
            />
          </div>
        </div>

        {/* Session Closed Overlay */}
        {!isLoading && isPOSDisabled && (
          <SessionClosedOverlay 
            message={!shift ? "No hay turno abierto" : "La caja esta cerrada o no iniciada"}
          />
        )}
      </div>

      {/* Payment Modal */}
      <PaymentModal
        total={cartTotal}
        isOpen={paymentModalOpen}
        onClose={() => setPaymentModalOpen(false)}
        onConfirm={handlePaymentConfirm}
        loading={paymentLoading}
      />

      {/* Gift Modal */}
      <GiftModal
        total={cartTotal}
        isOpen={giftModalOpen}
        onClose={() => setGiftModalOpen(false)}
        onConfirm={handleGiftConfirm}
        rrpps={rrpps}
        loading={giftLoading}
      />

      {/* Receipt Modal */}
      <ReceiptModal
        saleId={lastSaleId}
        isOpen={receiptModalOpen}
        onClose={() => setReceiptModalOpen(false)}
      />

      {/* Recent Sales Modal */}
      <RecentSalesModal
        isOpen={recentSalesModalOpen}
        onClose={() => setRecentSalesModalOpen(false)}
        sales={recentSales}
        onPrintSale={handlePrintSale}
      />
    </div>
  )
}
