"use client"

import { useEffect, useState, useRef } from "react"
import { X, Printer, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { formatCurrency } from "@/lib/types"
import { getSaleWithItems, markSaleAsPrinted } from "@/lib/sales-actions"

interface ReceiptModalProps {
  saleId: string | null
  isOpen: boolean
  onClose: () => void
}

interface SaleData {
  id: string
  receipt_number: string | null
  sale_type: string
  total_amount: number
  created_at: string
  bar?: { name: string } | null
  rrpp?: { full_name: string } | null
  items: Array<{
    quantity: number
    unit_price: number
    subtotal: number
    product?: { name: string } | null
  }>
  payments: Array<{
    payment_method: string
    amount: number
  }>
}

export function ReceiptModal({ saleId, isOpen, onClose }: ReceiptModalProps) {
  const [sale, setSale] = useState<SaleData | null>(null)
  const [loading, setLoading] = useState(false)
  const receiptRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isOpen && saleId) {
      setLoading(true)
      getSaleWithItems(saleId)
        .then((data) => {
          setSale(data)
          setLoading(false)
        })
        .catch(() => {
          setLoading(false)
        })
    }
  }, [isOpen, saleId])

  const handlePrint = async () => {
    if (saleId) {
      await markSaleAsPrinted(saleId)
    }
    window.print()
    onClose()
  }

  const handleSkip = () => {
    onClose()
  }

  if (!isOpen) return null

  return (
    <>
      {/* Print styles */}
      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #receipt-print, #receipt-print * {
            visibility: visible;
          }
          #receipt-print {
            position: absolute;
            left: 0;
            top: 0;
            width: 80mm;
            padding: 10mm;
          }
        }
      `}</style>

      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={onClose} />
        <div className="relative w-full max-w-md bg-card rounded-3xl shadow-2xl border border-border/50 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-5 border-b border-border/50">
            <h2 className="text-xl font-semibold text-foreground">Comprobante</h2>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-muted/50 flex items-center justify-center hover:bg-muted transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-5">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="w-8 h-8 border-2 border-foreground/20 border-t-foreground rounded-full animate-spin" />
              </div>
            ) : sale ? (
              <>
                {/* Receipt Preview */}
                <div 
                  ref={receiptRef}
                  id="receipt-print"
                  className="bg-white text-black p-4 rounded-xl mb-5 font-mono text-sm"
                >
                  <div className="text-center mb-4">
                    <p className="font-bold text-lg">{sale.bar?.name || "Bar"}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(sale.created_at).toLocaleString("es-AR")}
                    </p>
                    {sale.receipt_number && (
                      <p className="text-xs">Ticket #{sale.receipt_number}</p>
                    )}
                  </div>

                  <div className="border-t border-dashed border-gray-300 my-2" />

                  {sale.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between py-1">
                      <span>
                        {item.quantity}x {item.product?.name || "Producto"}
                      </span>
                      <span>{formatCurrency(item.subtotal)}</span>
                    </div>
                  ))}

                  <div className="border-t border-dashed border-gray-300 my-2" />

                  <div className="flex justify-between font-bold text-base">
                    <span>TOTAL</span>
                    <span>{formatCurrency(sale.total_amount)}</span>
                  </div>

                  {sale.sale_type === "gift" && sale.rrpp && (
                    <div className="mt-2 text-center text-xs text-gray-500">
                      Regalo - RRPP: {sale.rrpp.full_name}
                    </div>
                  )}

                  {sale.payments && sale.payments.length > 0 && (
                    <div className="mt-2 text-xs text-gray-500">
                      <p className="font-semibold">Pagos:</p>
                      {sale.payments.map((p, idx) => (
                        <p key={idx}>
                          {p.payment_method}: {formatCurrency(p.amount)}
                        </p>
                      ))}
                    </div>
                  )}

                  <div className="text-center mt-4 text-xs text-gray-400">
                    Gracias por su compra
                  </div>
                </div>

                {/* Question */}
                <div className="text-center mb-4">
                  <p className="text-lg font-medium text-foreground">
                    Desea imprimir comprobante?
                  </p>
                </div>
              </>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No se pudo cargar el comprobante
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-5 border-t border-border/50">
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                size="lg"
                onClick={handleSkip}
                className="rounded-xl h-12 font-medium"
              >
                <XCircle className="w-4 h-4 mr-2" />
                No imprimir
              </Button>
              <Button
                size="lg"
                onClick={handlePrint}
                disabled={loading || !sale}
                className="rounded-xl h-12 font-medium bg-foreground text-background hover:bg-foreground/90"
              >
                <Printer className="w-4 h-4 mr-2" />
                Imprimir
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
