"use client"

import { Lock, AlertTriangle } from "lucide-react"

interface SessionClosedOverlayProps {
  message?: string
}

export function SessionClosedOverlay({ message }: SessionClosedOverlayProps) {
  return (
    <div className="absolute inset-0 z-40 bg-background/95 backdrop-blur-sm flex items-center justify-center">
      <div className="text-center max-w-sm mx-auto px-6">
        <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
          <Lock className="w-10 h-10 text-muted-foreground" />
        </div>
        <h2 className="text-2xl font-semibold text-foreground mb-2">Caja Cerrada</h2>
        <p className="text-muted-foreground mb-6">
          {message || "La caja esta cerrada o no ha sido iniciada. Contacta a un administrador para abrir la caja."}
        </p>
        <div className="flex items-center justify-center gap-2 text-sm text-amber-600 bg-amber-500/10 px-4 py-3 rounded-xl">
          <AlertTriangle className="w-4 h-4" />
          <span>Solo administradores pueden abrir la caja</span>
        </div>
      </div>
    </div>
  )
}
