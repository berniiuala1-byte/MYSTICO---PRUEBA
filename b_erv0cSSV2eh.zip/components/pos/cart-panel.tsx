"use client"

import { Minus, Plus, Trash2, Gift, CreditCard, Receipt } from "lucide-react"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/types"
import type { CartItem } from "@/lib/types"
import { Button } from "@/components/ui/button"

interface CartPanelProps {
  items: CartItem[]
  onUpdateQuantity: (productId: string, delta: number) => void
  onRemoveItem: (productId: string) => void
  onCheckout: () => void
  onGift: () => void
  onViewRecent: () => void
  disabled?: boolean
}

export function CartPanel({
  items,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  onGift,
  onViewRecent,
  disabled,
}: CartPanelProps) {
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <div className="flex flex-col h-full bg-card rounded-2xl border border-border/50 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-border/50">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-lg text-foreground">Pedido Actual</h2>
          <div className="flex items-center gap-2">
            <button
              onClick={onViewRecent}
              className="w-8 h-8 rounded-lg bg-muted/50 flex items-center justify-center hover:bg-muted transition-colors"
              title="Ventas recientes"
            >
              <Receipt className="w-4 h-4" />
            </button>
            <span className="text-sm text-muted-foreground">
              {itemCount} {itemCount === 1 ? "item" : "items"}
            </span>
          </div>
        </div>
      </div>

      {/* Items */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
            <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mb-3">
              <CreditCard className="w-8 h-8" />
            </div>
            <p className="text-sm font-medium">Sin productos</p>
            <p className="text-xs">Toca productos para agregar</p>
          </div>
        ) : (
          items.map((item) => (
            <div
              key={item.id}
              className="flex items-center gap-3 p-3 bg-background rounded-xl border border-border/30"
            >
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-foreground truncate">
                  {item.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(item.price)} c/u
                </p>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
                  <button
                    onClick={() => onUpdateQuantity(item.id, -1)}
                    disabled={disabled}
                    className={cn(
                      "w-7 h-7 rounded-md flex items-center justify-center transition-colors",
                      "hover:bg-background text-muted-foreground hover:text-foreground",
                      disabled && "opacity-50 cursor-not-allowed"
                    )}
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-6 text-center font-medium text-sm">
                    {item.quantity}
                  </span>
                  <button
                    onClick={() => onUpdateQuantity(item.id, 1)}
                    disabled={disabled}
                    className={cn(
                      "w-7 h-7 rounded-md flex items-center justify-center transition-colors",
                      "hover:bg-background text-muted-foreground hover:text-foreground",
                      disabled && "opacity-50 cursor-not-allowed"
                    )}
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
                <span className="w-20 text-right font-semibold text-sm">
                  {formatCurrency(item.price * item.quantity)}
                </span>
                <button
                  onClick={() => onRemoveItem(item.id)}
                  disabled={disabled}
                  className={cn(
                    "w-7 h-7 rounded-md flex items-center justify-center transition-colors",
                    "text-muted-foreground hover:text-destructive hover:bg-destructive/10",
                    disabled && "opacity-50 cursor-not-allowed"
                  )}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-border/50 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground font-medium">Total</span>
          <span className="text-2xl font-bold text-foreground">
            {formatCurrency(total)}
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="outline"
            size="lg"
            onClick={onGift}
            disabled={disabled || items.length === 0}
            className="rounded-xl h-12 font-medium"
          >
            <Gift className="w-4 h-4 mr-2" />
            Regalo / RRPP
          </Button>
          <Button
            size="lg"
            onClick={onCheckout}
            disabled={disabled || items.length === 0}
            className="rounded-xl h-12 font-medium bg-foreground text-background hover:bg-foreground/90"
          >
            <CreditCard className="w-4 h-4 mr-2" />
            Cobrar
          </Button>
        </div>
      </div>
    </div>
  )
}
