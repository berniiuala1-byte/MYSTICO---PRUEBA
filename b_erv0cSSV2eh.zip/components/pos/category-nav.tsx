"use client"

import { cn } from "@/lib/utils"
import type { ProductCategory } from "@/lib/types"

interface CategoryNavProps {
  categories: ProductCategory[]
  selectedCategory: string
  onSelectCategory: (categoryId: string) => void
}

export function CategoryNav({ categories, selectedCategory, onSelectCategory }: CategoryNavProps) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
      <button
        onClick={() => onSelectCategory("all")}
        className={cn(
          "flex items-center gap-2 px-5 py-3 rounded-2xl font-medium text-sm whitespace-nowrap transition-all",
          "shadow-sm border border-border/50",
          selectedCategory === "all"
            ? "bg-foreground text-background shadow-md"
            : "bg-card text-muted-foreground hover:bg-accent hover:text-foreground"
        )}
      >
        Todos
      </button>
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onSelectCategory(category.id)}
          className={cn(
            "flex items-center gap-2 px-5 py-3 rounded-2xl font-medium text-sm whitespace-nowrap transition-all",
            "shadow-sm border border-border/50",
            selectedCategory === category.id
              ? "bg-foreground text-background shadow-md"
              : "bg-card text-muted-foreground hover:bg-accent hover:text-foreground"
          )}
        >
          {category.name}
        </button>
      ))}
    </div>
  )
}
