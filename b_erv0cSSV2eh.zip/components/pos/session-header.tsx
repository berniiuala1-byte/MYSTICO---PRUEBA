"use client"

import { CircleDot, Lock, ChevronDown, Check } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Bar, CashSession, Shift } from "@/lib/types"
import { useState } from "react"

interface SessionHeaderProps {
  bar: Bar | null
  bars: Bar[]
  cashSession: CashSession | null
  shift: Shift | null
  onSelectBar: (bar: Bar) => void
  loading?: boolean
}

export function SessionHeader({ bar, bars, cashSession, shift, onSelectBar, loading }: SessionHeaderProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const isOpen = !!cashSession && cashSession.status === "open"

  return (
    <header className="flex items-center justify-between py-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-foreground text-background flex items-center justify-center font-bold text-lg">
          {bar?.name.charAt(0) || "B"}
        </div>
        <div>
          {/* Bar Selector */}
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center gap-1 font-semibold text-lg text-foreground hover:text-foreground/80 transition-colors"
            >
              {bar?.name || "Seleccionar Bar"}
              {bars.length > 1 && <ChevronDown className={cn("w-4 h-4 transition-transform", dropdownOpen && "rotate-180")} />}
            </button>
            
            {dropdownOpen && bars.length > 1 && (
              <div className="absolute z-20 top-full left-0 mt-2 w-48 bg-card rounded-xl border border-border/50 shadow-xl overflow-hidden">
                {bars.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => {
                      onSelectBar(b)
                      setDropdownOpen(false)
                    }}
                    className={cn(
                      "w-full flex items-center justify-between p-3 hover:bg-muted/50 transition-colors text-left",
                      bar?.id === b.id && "bg-muted/50"
                    )}
                  >
                    <span className="font-medium">{b.name}</span>
                    {bar?.id === b.id && <Check className="w-4 h-4" />}
                  </button>
                ))}
              </div>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {shift?.name || "Sin turno"} {shift?.event_date ? `- ${new Date(shift.event_date).toLocaleDateString("es-AR")}` : ""}
          </p>
        </div>
      </div>

      <div
        className={cn(
          "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium",
          loading
            ? "bg-muted text-muted-foreground"
            : isOpen
            ? "bg-green-500/10 text-green-600"
            : "bg-destructive/10 text-destructive"
        )}
      >
        {loading ? (
          <>
            <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
            Cargando...
          </>
        ) : isOpen ? (
          <>
            <CircleDot className="w-4 h-4 animate-pulse" />
            Caja Abierta
          </>
        ) : (
          <>
            <Lock className="w-4 h-4" />
            Caja Cerrada
          </>
        )}
      </div>
    </header>
  )
}
