"use client"

import { useState, useEffect } from "react"
import { X, Banknote, CreditCard, Check, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

type BankMethod = 'transfer' | 'posnet' | 'qr' | 'mercado_pago'

interface PaymentResult {
  cashAmount: number
  bankAmount: number
  bankMethod: BankMethod
}

interface PaymentModalProps {
  total: number
  isOpen: boolean
  onClose: () => void
  onConfirm: (result: PaymentResult) => void
  loading?: boolean
}

export function PaymentModal({ total, isOpen, onClose, onConfirm, loading }: PaymentModalProps) {
  const [cashAmount, setCashAmount] = useState<string>("")
  const [bankAmount, setBankAmount] = useState<string>("")
  const [bankMethod, setBankMethod] = useState<BankMethod>("posnet")
  const [activeField, setActiveField] = useState<"cash" | "bank">("cash")

  const cashNum = parseFloat(cashAmount) || 0
  const bankNum = parseFloat(bankAmount) || 0
  const totalPaid = cashNum + bankNum
  const remaining = total - totalPaid
  const isValid = totalPaid === total
  const isOverpaid = totalPaid > total

  useEffect(() => {
    if (isOpen) {
      setCashAmount("")
      setBankAmount("")
      setBankMethod("posnet")
      setActiveField("cash")
    }
  }, [isOpen])

  const handleCashChange = (value: string) => {
    const num = parseFloat(value) || 0
    if (num > total) {
      setCashAmount(total.toString())
      setBankAmount("0")
    } else {
      setCashAmount(value)
    }
  }

  const handleBankChange = (value: string) => {
    const num = parseFloat(value) || 0
    if (num > total) {
      setBankAmount(total.toString())
      setCashAmount("0")
    } else {
      setBankAmount(value)
    }
  }

  const handleFullCash = () => {
    setCashAmount(total.toString())
    setBankAmount("0")
  }

  const handleFullBank = () => {
    setBankAmount(total.toString())
    setCashAmount("0")
  }

  const handleFillRemaining = () => {
    if (activeField === "cash") {
      setCashAmount(remaining.toString())
    } else {
      setBankAmount(remaining.toString())
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-card rounded-3xl shadow-2xl border border-border/50 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border/50">
          <h2 className="text-xl font-semibold text-foreground">Cobrar</h2>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-muted/50 flex items-center justify-center hover:bg-muted transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-5">
          {/* Total */}
          <div className="text-center py-4 bg-muted/30 rounded-2xl">
            <p className="text-sm text-muted-foreground mb-1">Total a Cobrar</p>
            <p className="text-3xl font-bold text-foreground">{formatCurrency(total)}</p>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={handleFullCash}
              className={cn(
                "flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all",
                cashNum === total && bankNum === 0
                  ? "border-foreground bg-foreground/5"
                  : "border-border/50 hover:border-border"
              )}
            >
              <Banknote className="w-6 h-6" />
              <span className="text-sm font-medium">Todo Efectivo</span>
            </button>
            <button
              onClick={handleFullBank}
              className={cn(
                "flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all",
                bankNum === total && cashNum === 0
                  ? "border-foreground bg-foreground/5"
                  : "border-border/50 hover:border-border"
              )}
            >
              <CreditCard className="w-6 h-6" />
              <span className="text-sm font-medium">Todo Banco</span>
            </button>
          </div>

          {/* Split Payment */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="h-px flex-1 bg-border" />
              <span className="text-xs text-muted-foreground font-medium uppercase">Pago Mixto</span>
              <div className="h-px flex-1 bg-border" />
            </div>

            <div className="space-y-3">
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground flex items-center gap-2">
                  <Banknote className="w-4 h-4" />
                  Efectivo
                </Label>
                <Input
                  type="number"
                  placeholder="0"
                  value={cashAmount}
                  onChange={(e) => handleCashChange(e.target.value)}
                  onFocus={() => setActiveField("cash")}
                  className="h-12 rounded-xl text-lg font-medium"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  Banco
                </Label>
                <Input
                  type="number"
                  placeholder="0"
                  value={bankAmount}
                  onChange={(e) => handleBankChange(e.target.value)}
                  onFocus={() => setActiveField("bank")}
                  className="h-12 rounded-xl text-lg font-medium"
                />
                
                {/* Bank Method Selection */}
                {bankNum > 0 && (
                  <div className="flex gap-2 mt-2">
                    {(['posnet', 'transfer', 'qr', 'mercado_pago'] as BankMethod[]).map((method) => (
                      <button
                        key={method}
                        onClick={() => setBankMethod(method)}
                        className={cn(
                          "flex-1 py-2 px-3 rounded-lg text-xs font-medium transition-all",
                          bankMethod === method
                            ? "bg-foreground text-background"
                            : "bg-muted/50 text-muted-foreground hover:bg-muted"
                        )}
                      >
                        {method === 'posnet' ? 'Posnet' : 
                         method === 'transfer' ? 'Transf.' : 
                         method === 'qr' ? 'QR' : 'MP'}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {remaining > 0 && (
              <button
                onClick={handleFillRemaining}
                className="w-full py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Completar {formatCurrency(remaining)} en {activeField === "cash" ? "Efectivo" : "Banco"}
              </button>
            )}
          </div>

          {/* Status */}
          <div
            className={cn(
              "p-4 rounded-2xl text-center",
              isValid && "bg-green-500/10 text-green-600",
              isOverpaid && "bg-destructive/10 text-destructive",
              !isValid && !isOverpaid && "bg-muted/50 text-muted-foreground"
            )}
          >
            {isValid ? (
              <div className="flex items-center justify-center gap-2">
                <Check className="w-5 h-5" />
                <span className="font-medium">Pago Completo</span>
              </div>
            ) : isOverpaid ? (
              <span className="font-medium">Excede el total por {formatCurrency(totalPaid - total)}</span>
            ) : (
              <span className="font-medium">Falta: {formatCurrency(remaining)}</span>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-5 border-t border-border/50">
          <Button
            size="lg"
            onClick={() => onConfirm({ cashAmount: cashNum, bankAmount: bankNum, bankMethod })}
            disabled={!isValid || loading}
            className="w-full h-14 rounded-2xl text-lg font-semibold bg-foreground text-background hover:bg-foreground/90 disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Procesando...
              </>
            ) : (
              "Confirmar Cobro"
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
