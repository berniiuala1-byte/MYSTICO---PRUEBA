"use client"

import { X, Receipt, Printer, Gift } from "lucide-react"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/types"
import type { Sale } from "@/lib/types"

interface RecentSalesModalProps {
  isOpen: boolean
  onClose: () => void
  sales: Sale[]
  onPrintSale: (saleId: string) => void
}

export function RecentSalesModal({ isOpen, onClose, sales, onPrintSale }: RecentSalesModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-card rounded-3xl shadow-2xl border border-border/50 overflow-hidden max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border/50">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center">
              <Receipt className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-semibold text-foreground">Ventas Recientes</h2>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-muted/50 flex items-center justify-center hover:bg-muted transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5">
          {sales.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Receipt className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No hay ventas recientes</p>
            </div>
          ) : (
            <div className="space-y-2">
              {sales.map((sale) => (
                <div
                  key={sale.id}
                  className="flex items-center justify-between p-4 bg-background rounded-xl border border-border/30"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      {sale.sale_type === "gift" && (
                        <Gift className="w-4 h-4 text-amber-500" />
                      )}
                      <p className="font-medium text-foreground">
                        {sale.receipt_number ? `#${sale.receipt_number}` : `Venta`}
                      </p>
                      <span className={cn(
                        "text-xs px-2 py-0.5 rounded-full",
                        sale.sale_type === "gift" 
                          ? "bg-amber-500/10 text-amber-600"
                          : "bg-green-500/10 text-green-600"
                      )}>
                        {sale.sale_type === "gift" ? "Regalo" : "Normal"}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {new Date(sale.created_at).toLocaleString("es-AR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-foreground">
                      {formatCurrency(sale.total_amount || 0)}
                    </span>
                    <button
                      onClick={() => onPrintSale(sale.id)}
                      className="w-9 h-9 rounded-full bg-muted/50 flex items-center justify-center hover:bg-muted transition-colors"
                      title="Reimprimir"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
