"use client"

import Image from "next/image"
import { Plus } from "lucide-react"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/types"
import type { Product } from "@/lib/types"

interface ProductGridProps {
  products: Product[]
  onAddProduct: (product: Product) => void
  disabled?: boolean
}

export function ProductGrid({ products, onAddProduct, disabled }: ProductGridProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
      {products.map((product) => (
        <button
          key={product.id}
          onClick={() => onAddProduct(product)}
          disabled={disabled}
          className={cn(
            "group relative flex flex-col bg-card rounded-2xl overflow-hidden transition-all",
            "border border-border/50 shadow-sm",
            "hover:shadow-lg hover:scale-[1.02] hover:border-border",
            "active:scale-[0.98]",
            disabled && "opacity-50 cursor-not-allowed hover:scale-100 hover:shadow-sm"
          )}
        >
          <div className="relative aspect-square bg-muted/50">
            {product.image_url ? (
              <Image
                src={product.image_url}
                alt={product.name}
                fill
                className="object-cover"
                sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-2xl font-bold">
                {product.name.charAt(0)}
              </div>
            )}
            <div className={cn(
              "absolute inset-0 bg-foreground/0 group-hover:bg-foreground/5 transition-colors",
              "flex items-center justify-center"
            )}>
              <div className={cn(
                "w-10 h-10 rounded-full bg-foreground text-background",
                "flex items-center justify-center",
                "opacity-0 group-hover:opacity-100 scale-75 group-hover:scale-100",
                "transition-all duration-200",
                disabled && "group-hover:opacity-0"
              )}>
                <Plus className="w-5 h-5" />
              </div>
            </div>
          </div>
          <div className="p-3 flex flex-col gap-1">
            <span className="font-medium text-sm text-foreground line-clamp-1">
              {product.name}
            </span>
            <span className="text-base font-semibold text-foreground">
              {formatCurrency(product.sale_price || 0)}
            </span>
          </div>
        </button>
      ))}
    </div>
  )
}
