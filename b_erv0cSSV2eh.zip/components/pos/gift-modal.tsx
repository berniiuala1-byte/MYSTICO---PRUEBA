"use client"

import { useState, useEffect } from "react"
import { X, Gift, ChevronDown, Check, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/types"
import type { RRPP } from "@/lib/types"
import { Button } from "@/components/ui/button"

interface GiftModalProps {
  total: number
  isOpen: boolean
  onClose: () => void
  onConfirm: (rrpp: RRPP) => void
  rrpps: RRPP[]
  loading?: boolean
}

export function GiftModal({ total, isOpen, onClose, onConfirm, rrpps, loading }: GiftModalProps) {
  const [selectedRRPP, setSelectedRRPP] = useState<RRPP | null>(null)
  const [dropdownOpen, setDropdownOpen] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setSelectedRRPP(null)
      setDropdownOpen(false)
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-card rounded-3xl shadow-2xl border border-border/50 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border/50">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center">
              <Gift className="w-5 h-5 text-amber-500" />
            </div>
            <h2 className="text-xl font-semibold text-foreground">Regalo / RRPP</h2>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-muted/50 flex items-center justify-center hover:bg-muted transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-5">
          {/* Total */}
          <div className="text-center py-4 bg-amber-500/10 rounded-2xl">
            <p className="text-sm text-muted-foreground mb-1">Valor del Regalo</p>
            <p className="text-3xl font-bold text-amber-600">{formatCurrency(total)}</p>
          </div>

          {/* RRPP Selection */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">
              Seleccionar RRPP
            </label>
            <div className="relative">
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className={cn(
                  "w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-all",
                  "bg-background",
                  selectedRRPP ? "border-foreground" : "border-border/50 hover:border-border"
                )}
              >
                <span className={cn(selectedRRPP ? "text-foreground font-medium" : "text-muted-foreground")}>
                  {selectedRRPP ? selectedRRPP.full_name : "Elegir RRPP..."}
                </span>
                <ChevronDown className={cn("w-5 h-5 transition-transform", dropdownOpen && "rotate-180")} />
              </button>

              {dropdownOpen && (
                <div className="absolute z-10 w-full mt-2 bg-card rounded-2xl border border-border/50 shadow-xl overflow-hidden max-h-60 overflow-y-auto">
                  {rrpps.length === 0 ? (
                    <div className="p-4 text-center text-muted-foreground text-sm">
                      No hay RRPPs disponibles
                    </div>
                  ) : (
                    rrpps.map((rrpp) => (
                      <button
                        key={rrpp.id}
                        onClick={() => {
                          setSelectedRRPP(rrpp)
                          setDropdownOpen(false)
                        }}
                        className={cn(
                          "w-full flex items-center justify-between p-4 hover:bg-muted/50 transition-colors",
                          selectedRRPP?.id === rrpp.id && "bg-muted/50"
                        )}
                      >
                        <span className="font-medium">{rrpp.full_name}</span>
                        {selectedRRPP?.id === rrpp.id && <Check className="w-5 h-5 text-foreground" />}
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Info */}
          <div className="p-4 rounded-2xl bg-muted/30 text-sm text-muted-foreground">
            <p>
              Este pedido sera marcado como <span className="font-semibold text-foreground">regalo</span> y 
              asignado al RRPP seleccionado. No se requerira pago.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-5 border-t border-border/50">
          <Button
            size="lg"
            onClick={() => selectedRRPP && onConfirm(selectedRRPP)}
            disabled={!selectedRRPP || loading}
            className="w-full h-14 rounded-2xl text-lg font-semibold bg-amber-500 text-white hover:bg-amber-600 disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Procesando...
              </>
            ) : (
              <>
                <Gift className="w-5 h-5 mr-2" />
                Confirmar Regalo
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
