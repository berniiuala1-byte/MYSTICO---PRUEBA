// Database types from Supabase schema

export interface Product {
  id: string
  name: string
  description: string | null
  sku: string | null
  unit_type: string | null
  cost_price: number | null
  sale_price: number | null
  image_url: string | null
  is_sellable: boolean
  is_ingredient: boolean
  is_composite: boolean
  is_active: boolean
  category_id: string | null
  created_at: string
}

export interface ProductCategory {
  id: string
  name: string
  sort_order: number | null
  is_active: boolean
  created_at: string
}

export interface RRPP {
  id: string
  full_name: string
  phone: string | null
  notes: string | null
  is_active: boolean
  created_at: string
}

export interface Shift {
  id: string
  name: string | null
  event_date: string | null
  status: 'open' | 'closed'
  opened_by: string | null
  closed_by: string | null
  opened_at: string | null
  closed_at: string | null
  notes: string | null
}

export interface CashSession {
  id: string
  shift_id: string
  bar_id: string
  opened_by: string | null
  closed_by: string | null
  status: 'open' | 'closed'
  opening_cash: number
  expected_cash: number | null
  expected_bank: number | null
  counted_cash: number | null
  counted_bank: number | null
  cash_difference: number | null
  bank_difference: number | null
  total_difference: number | null
  opened_at: string
  closed_at: string | null
  notes: string | null
}

export interface Bar {
  id: string
  name: string
  location: string | null
  is_active: boolean
  created_at: string
}

export interface Sale {
  id: string
  shift_id: string
  cash_session_id: string
  bar_id: string
  user_id: string | null
  rrpp_id: string | null
  receipt_number: string | null
  sale_type: 'normal' | 'gift'
  status: 'pending' | 'completed' | 'cancelled' | 'refunded'
  subtotal: number | null
  discount_amount: number | null
  total_amount: number | null
  paid_amount: number | null
  notes: string | null
  print_count: number | null
  printed_at: string | null
  created_at: string
}

export interface SaleItem {
  id: string
  sale_id: string
  product_id: string
  quantity: number
  unit_price: number
  subtotal: number
  created_at: string
}

export interface SalePayment {
  id: string
  sale_id: string
  payment_account: 'cash' | 'bank'
  payment_method: 'cash' | 'transfer' | 'posnet' | 'qr' | 'mercado_pago'
  amount: number
  created_at: string
}

export interface DashboardBarSales {
  shift_id: string
  cash_session_id: string
  bar_id: string
  bar_name: string
  cash_status: 'open' | 'closed'
  opening_cash: number | null
  total_sales: number | null
  total_gifts: number | null
  total_orders: number | null
  expected_cash: number | null
  expected_bank: number | null
}

// Cart item for POS
export interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  image_url: string | null
}

// Product with category for display
export interface ProductWithCategory extends Product {
  category?: ProductCategory | null
}

// Format currency helper
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    minimumFractionDigits: 0,
  }).format(amount)
}
