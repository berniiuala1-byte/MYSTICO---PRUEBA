"use client"

import { createClient } from "@/lib/supabase/client"
import type { CartItem, SalePayment } from "@/lib/types"

interface PaymentInput {
  payment_account: 'cash' | 'bank'
  payment_method: 'cash' | 'transfer' | 'posnet' | 'qr' | 'mercado_pago'
  amount: number
}

interface CreateSaleResult {
  success: boolean
  saleId?: string
  receiptNumber?: string
  error?: string
}

// Create a normal sale with payment
export async function createNormalSale(
  shiftId: string,
  cashSessionId: string,
  barId: string,
  items: CartItem[],
  payments: PaymentInput[]
): Promise<CreateSaleResult> {
  const supabase = createClient()

  // Calculate totals
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const totalPayment = payments.reduce((sum, p) => sum + p.amount, 0)

  // Validate payment covers total
  if (totalPayment < subtotal) {
    return { success: false, error: "El pago no cubre el total del pedido" }
  }

  if (totalPayment > subtotal) {
    return { success: false, error: "El pago excede el total del pedido" }
  }

  try {
    // 1. Insert sale
    const { data: sale, error: saleError } = await supabase
      .from("sales")
      .insert({
        shift_id: shiftId,
        cash_session_id: cashSessionId,
        bar_id: barId,
        sale_type: "normal",
        status: "completed",
        subtotal,
        total_amount: subtotal,
        paid_amount: totalPayment,
      })
      .select()
      .single()

    if (saleError) {
      console.error("Sale insert error:", saleError)
      return { success: false, error: saleError.message }
    }

    // 2. Insert sale items
    const saleItems = items.map((item) => ({
      sale_id: sale.id,
      product_id: item.id,
      quantity: item.quantity,
      unit_price: item.price,
      subtotal: item.price * item.quantity,
    }))

    const { error: itemsError } = await supabase
      .from("sale_items")
      .insert(saleItems)

    if (itemsError) {
      console.error("Sale items insert error:", itemsError)
      // Consider rolling back the sale here
      return { success: false, error: itemsError.message }
    }

    // 3. Insert payments
    const salePayments = payments.filter(p => p.amount > 0).map((p) => ({
      sale_id: sale.id,
      payment_account: p.payment_account,
      payment_method: p.payment_method,
      amount: p.amount,
    }))

    if (salePayments.length > 0) {
      const { error: paymentsError } = await supabase
        .from("sale_payments")
        .insert(salePayments)

      if (paymentsError) {
        console.error("Sale payments insert error:", paymentsError)
        return { success: false, error: paymentsError.message }
      }
    }

    return { 
      success: true, 
      saleId: sale.id,
      receiptNumber: sale.receipt_number
    }

  } catch (error) {
    console.error("Create sale error:", error)
    return { 
      success: false, 
      error: error instanceof Error ? error.message : "Error desconocido" 
    }
  }
}

// Create a gift sale (no payment)
export async function createGiftSale(
  shiftId: string,
  cashSessionId: string,
  barId: string,
  items: CartItem[],
  rrppId: string
): Promise<CreateSaleResult> {
  const supabase = createClient()

  // Validate RRPP is provided
  if (!rrppId) {
    return { success: false, error: "Debe seleccionar un RRPP para registrar el regalo" }
  }

  // Calculate totals
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)

  try {
    // 1. Insert sale
    const { data: sale, error: saleError } = await supabase
      .from("sales")
      .insert({
        shift_id: shiftId,
        cash_session_id: cashSessionId,
        bar_id: barId,
        rrpp_id: rrppId,
        sale_type: "gift",
        status: "completed",
        subtotal,
        total_amount: subtotal,
        paid_amount: 0,
      })
      .select()
      .single()

    if (saleError) {
      console.error("Gift sale insert error:", saleError)
      return { success: false, error: saleError.message }
    }

    // 2. Insert sale items
    const saleItems = items.map((item) => ({
      sale_id: sale.id,
      product_id: item.id,
      quantity: item.quantity,
      unit_price: item.price,
      subtotal: item.price * item.quantity,
    }))

    const { error: itemsError } = await supabase
      .from("sale_items")
      .insert(saleItems)

    if (itemsError) {
      console.error("Gift sale items insert error:", itemsError)
      return { success: false, error: itemsError.message }
    }

    return { 
      success: true, 
      saleId: sale.id,
      receiptNumber: sale.receipt_number 
    }

  } catch (error) {
    console.error("Create gift sale error:", error)
    return { 
      success: false, 
      error: error instanceof Error ? error.message : "Error desconocido" 
    }
  }
}

// Update print count for a sale
export async function markSaleAsPrinted(saleId: string): Promise<boolean> {
  const supabase = createClient()

  const { error } = await supabase
    .from("sales")
    .update({ 
      print_count: 1,
      printed_at: new Date().toISOString()
    })
    .eq("id", saleId)

  if (error) {
    console.error("Mark printed error:", error)
    return false
  }

  return true
}

// Get sale with items for receipt
export async function getSaleWithItems(saleId: string) {
  const supabase = createClient()

  const { data: sale, error: saleError } = await supabase
    .from("sales")
    .select(`
      *,
      bar:bars(name),
      rrpp:rrpps(full_name)
    `)
    .eq("id", saleId)
    .single()

  if (saleError) {
    console.error("Get sale error:", saleError)
    return null
  }

  const { data: items, error: itemsError } = await supabase
    .from("sale_items")
    .select(`
      *,
      product:products(name)
    `)
    .eq("sale_id", saleId)

  if (itemsError) {
    console.error("Get sale items error:", itemsError)
    return null
  }

  const { data: payments, error: paymentsError } = await supabase
    .from("sale_payments")
    .select("*")
    .eq("sale_id", saleId)

  if (paymentsError) {
    console.error("Get sale payments error:", paymentsError)
    return null
  }

  return { ...sale, items, payments }
}
